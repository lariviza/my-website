<?php
/**
 * Displays the post header
 *
 * @package WordPress
 * @subpackage cryptozfree
 */

the_title( '<h1 class="entry-title">', '</h1>' );
